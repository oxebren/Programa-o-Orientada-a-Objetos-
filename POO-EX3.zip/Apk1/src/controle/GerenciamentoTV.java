package controle;

import model.TV;

public class GerenciamentoTV {

	public static void main(String[] args) {
		
		TV t1 = new TV();
		t1.setMarca("LG");
		t1.setTvLigada(false);
		t1.setTamanho(42);
		t1.setVolume(0);
		t1.setVoltagem(0);
		t1.setCanal(0);
		
	     TV t2 = new TV ("Toshiba", false, 40, 0, 0, 0);
	     t1.detalhes();
	     t2.detalhes();
	     
	     System.out.println(t1.situacaoTelevisor());
	     System.out.println(t2.situacaoTelevisor());
	     System.out.println (t2.desligarTV());
	     System.out.println (t1.desligarTV());
	     System.out.println (t1.ligarTV());
	     System.out.println (t1.ligarTV());
	     System.out.println (t2.ligarTV());
	     System.out.println (t1.ligarTV());
	     
	     
	     
	     
	     
	     
	     
	     
	     
	}
}
	     
