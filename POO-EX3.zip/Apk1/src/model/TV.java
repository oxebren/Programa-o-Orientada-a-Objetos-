package model;

public class TV {
	
	private String marca;
	private boolean tvLigada;
	private int tamanho;
	private int volume;
	private int voltagem;
	private int canal;
	private boolean tvDesligada;
	
	//m�todo construtor simples 
	public TV() {
		super();
	}

	// m�todo construtor completo 
	public TV(String marca, boolean tvLigada, int tamanho, int volume, int voltagem, int canal) {
		super();
		this.marca = marca;
		this.tvLigada = tvLigada;
		this.tamanho = tamanho;
		this.volume = volume;
		this.voltagem = voltagem;
		this.canal = canal;
	}
	// primeiro m�todo p�blico 
	public void detalhes () {
		System.out.println ("----TV-----");
		System.out.println ("Marca:" +this.marca);
		System.out.println ("Tamanho:" +this.tamanho + "\n");	
	}
	// segundo m�todo p�blico
	
	public String situacaoTelevisor() {
		if (this.tvLigada) {
			return this.marca + "---> TV Ligada!";
		}else {
			return this.marca + "---> TV Desligada!";
				
		}
		
	}
	
	//terceiro m�todo p�blico  
	public String ligarTV() {
		if (this.tvLigada) {
			return "O motor da(o)" + this.marca + "j� estava ligada.";
		}else {
			this.tvLigada = true; // Estou ligando motor 
			return "O motor da(o)" + this.marca + "foi ligada agora.";
			
			
		}
		
		
	}
	
	public String desligarTV() {
		if (!this.tvLigada) {
			return "A TV " + this.marca + "j� estava desligada.";
		}else {
			this.tvLigada = true; // Estou ligando a tv 
			return " A TV" + this.marca + "foi ligada agora.";
	
		}
	
	}
	
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public boolean isTvLigada() {
		return tvLigada;
	}

	public void setTvLigada(boolean tvLigada) {
		this.tvLigada = tvLigada;
	}

	public int getTamanho() {
		return tamanho;
	}

	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}

	public int getVoltagem() {
		return voltagem;
	}

	public void setVoltagem(int voltagem) {
		this.voltagem = voltagem;
	}

	public int getCanal() {
		return canal;
	}

	public void setCanal(int canal) {
		this.canal = canal;
	}
	
	
	
	
	

}
